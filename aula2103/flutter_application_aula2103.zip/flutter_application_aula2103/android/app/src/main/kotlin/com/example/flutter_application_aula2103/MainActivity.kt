package com.example.flutter_application_aula2103

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
